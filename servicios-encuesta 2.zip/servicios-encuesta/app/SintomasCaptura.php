<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SintomasCaptura extends Model
{
    protected $table = "sintomas_captura";
}
