<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CapturasEncuesta extends Model
{
    protected $table = "capturas_encuesta";
}
