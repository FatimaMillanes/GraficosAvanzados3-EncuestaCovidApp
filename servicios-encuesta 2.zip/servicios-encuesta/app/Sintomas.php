<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sintomas extends Model
{
    protected $table = "sintomas";
}
