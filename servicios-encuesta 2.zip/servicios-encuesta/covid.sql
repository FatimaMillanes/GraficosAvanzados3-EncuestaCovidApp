-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 30, 2022 at 01:01 AM
-- Server version: 5.7.26
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid`
--

-- --------------------------------------------------------

--
-- Table structure for table `capturas_encuesta`
--

CREATE TABLE `capturas_encuesta` (
  `id` int(11) NOT NULL,
  `id_tipo_usuario` int(11) NOT NULL,
  `matricula` text,
  `numero_profesor` text,
  `numero_empleado` text,
  `nombre` text NOT NULL,
  `correo` text NOT NULL,
  `contacto_covid` tinyint(1) NOT NULL,
  `vacunado` tinyint(1) NOT NULL,
  `cadena_qr` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `capturas_encuesta`
--

INSERT INTO `capturas_encuesta` (`id`, `id_tipo_usuario`, `matricula`, `numero_profesor`, `numero_empleado`, `nombre`, `correo`, `contacto_covid`, `vacunado`, `cadena_qr`, `created_at`, `updated_at`) VALUES
(1, 1, '1244355', NULL, NULL, 'Fatima', 'fatima@hotmail.com', 0, 1, '123456789', '2022-04-30 07:43:04', '2022-04-30 07:43:04'),
(2, 2, NULL, NULL, NULL, 'Raul', 'raul@hotmail.com', 0, 1, '123456789', '2022-04-30 07:56:00', '2022-04-30 07:56:00'),
(3, 2, NULL, NULL, NULL, 'Raul', 'raul@hotmail.com', 0, 1, '123456789', '2022-04-30 07:56:20', '2022-04-30 07:56:20'),
(4, 2, NULL, NULL, NULL, 'Raul', 'raul@hotmail.com', 0, 1, '123456789', '2022-04-30 07:56:42', '2022-04-30 07:56:42'),
(5, 2, NULL, NULL, NULL, 'Raul', 'raul@hotmail.com', 0, 1, '123456789', '2022-04-30 07:57:40', '2022-04-30 07:57:40');

-- --------------------------------------------------------

--
-- Table structure for table `sintomas`
--

CREATE TABLE `sintomas` (
  `id` int(11) NOT NULL,
  `descripcion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sintomas`
--

INSERT INTO `sintomas` (`id`, `descripcion`) VALUES
(1, 'Estoy positivo a covid'),
(2, 'Fiebre o escalofrios'),
(3, 'tos o catarro'),
(4, 'dolor de cabeza o garganta'),
(5, 'cansancio o malestar general'),
(6, 'perdida del gusto'),
(7, 'perdida del olfato'),
(8, 'ninguno de los anteriores');

-- --------------------------------------------------------

--
-- Table structure for table `sintomas_captura`
--

CREATE TABLE `sintomas_captura` (
  `id` int(11) NOT NULL,
  `id_captura` int(11) NOT NULL,
  `id_sintoma` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sintomas_captura`
--

INSERT INTO `sintomas_captura` (`id`, `id_captura`, `id_sintoma`, `created_at`, `updated_at`) VALUES
(1, 5, 3, '2022-04-30 07:57:40', '2022-04-30 07:57:40'),
(2, 5, 5, '2022-04-30 07:57:40', '2022-04-30 07:57:40');

-- --------------------------------------------------------

--
-- Table structure for table `tipos_usuarios`
--

CREATE TABLE `tipos_usuarios` (
  `id` int(11) NOT NULL,
  `tipo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tipos_usuarios`
--

INSERT INTO `tipos_usuarios` (`id`, `tipo`) VALUES
(1, 'Alumno'),
(2, 'Profesor'),
(3, 'Empleado');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `capturas_encuesta`
--
ALTER TABLE `capturas_encuesta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sintomas`
--
ALTER TABLE `sintomas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sintomas_captura`
--
ALTER TABLE `sintomas_captura`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `combinacion_unica` (`id_captura`,`id_sintoma`),
  ADD KEY `id_sintoma` (`id_sintoma`),
  ADD KEY `id_captura` (`id_captura`) USING BTREE;

--
-- Indexes for table `tipos_usuarios`
--
ALTER TABLE `tipos_usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `capturas_encuesta`
--
ALTER TABLE `capturas_encuesta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sintomas`
--
ALTER TABLE `sintomas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sintomas_captura`
--
ALTER TABLE `sintomas_captura`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tipos_usuarios`
--
ALTER TABLE `tipos_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sintomas_captura`
--
ALTER TABLE `sintomas_captura`
  ADD CONSTRAINT `sintomas_captura_ibfk_1` FOREIGN KEY (`id_captura`) REFERENCES `capturas_encuesta` (`id`),
  ADD CONSTRAINT `sintomas_captura_ibfk_2` FOREIGN KEY (`id_sintoma`) REFERENCES `sintomas` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
